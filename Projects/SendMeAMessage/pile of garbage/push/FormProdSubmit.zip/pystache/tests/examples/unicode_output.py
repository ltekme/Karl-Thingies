# encoding: utf-8

"""
TODO: add a docstring.

"""

class UnicodeOutput(object):

    def name(self):
        return 'Henri Poincaré'
